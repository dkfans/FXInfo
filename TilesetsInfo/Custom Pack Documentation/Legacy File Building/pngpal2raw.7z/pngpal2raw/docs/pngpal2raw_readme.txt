KeeperFX graphics sprites converter
------------------------------

This tool converts .png files into formats which are native to the game engine.
It can bes used to create .raw files, but also .dat and .jty sprite catalogues.
It requires either .png or .txt file with list of png images at input. 
Additionally, there must be input pal file which stores palette used for the sprites.
