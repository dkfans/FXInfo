
Best 8bpp palette selector for a series of PNG files (Png2bestPal)
  Created by Tomasz Lis; GNU General Public License
----------------------------------------
usage:

    png2bestpal.exe [options] <filename>
where <filename> should be the input BMP file, and [options] are:
    -v,--verbose             Verbose console output mode
    -m<file>,--palmap<file>  Static palette entries mapping file name
    -o<file>,--output<file>  Output PAL file name
